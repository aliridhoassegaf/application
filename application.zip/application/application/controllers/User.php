<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class User extends CI_Controller {
	public function __construct(){
		parent::__construct();
		$this->load->model('Log_model');
	}
	public function index()
	{
		if($_POST!=NULL){
			$this->form_validation->set_rules('username','username','required');
			$this->form_validation->set_rules('password','password','required');
			$this->form_validation->set_message('required','Harap isi %s anda');
			if($this->form_validation->run()){
				
				$username=$this->input->post('username');
				$password=md5($this->input->post('password'));
				
				$url = "smec-group.com:9123/user/login";
				$curlHandle = curl_init();
				curl_setopt($curlHandle, CURLOPT_URL, $url);
				curl_setopt($curlHandle, CURLOPT_POSTFIELDS,"username=".$username."&password=".$password);
				curl_setopt($curlHandle, CURLOPT_HEADER, 0);
				curl_setopt($curlHandle, CURLOPT_RETURNTRANSFER, 1);
				curl_setopt($curlHandle, CURLOPT_TIMEOUT,30);
				curl_setopt($curlHandle, CURLOPT_POST, 1);
				
				$show=curl_exec($curlHandle);
				$decode_data=json_decode($show);
				if($decode_data->message=="User tidak ada"){
					$this->session->set_flashdata("not_found","User tidak ada");
					redirect();
				}
				else if($decode_data->message=="Password salah"){
					$this->session->set_flashdata("pass_wrong","Password salah");
					redirect();
				}
				else{
					$token=$decode_data->token;
					$access=$decode_data->access;
					$expires_in=$decode_data->expires_in;
					date_default_timezone_set("Asia/Bangkok");
					$start_session=date("Y-m-d H:i:s");
					
					$this->Log_model->create($username, $token, $start_session);

					$userData = array(
						'username' => $username,
						'token' => $token,
						'access'=> $access,
						'expires_in'=> $expires_in,
						'start_session' => $start_session,
					);
					$this->session->set_userdata($userData);
					redirect('user/access');
					echo "sukses";
				}
			}
		}
		$this->load->view('login');
	}
	public function access(){
		$curl = curl_init();

		curl_setopt_array($curl, array(
			CURLOPT_URL => "smec-group.com:9123/user/access",
			CURLOPT_RETURNTRANSFER => true,
			CURLOPT_ENCODING => "",
			CURLOPT_MAXREDIRS => 10,
			CURLOPT_TIMEOUT => 30,
			CURLOPT_HTTP_VERSION => CURL_HTTP_VERSION_1_1,
			CURLOPT_CUSTOMREQUEST => "GET",
			CURLOPT_HTTPHEADER => array(
				"X-token: ".$this->session->userdata('token')
			),
		));

		$show=curl_exec($curl);
		$decode_data=json_decode($show);
		$data['decode_data']=$decode_data;
		$this->session->sess_expiration = $decode_data->expires_in;
		$this->load->view('home',$data);
	}
	public function logout()
	{

		$curlHandle = curl_init();

			curl_setopt_array($curl, array(
			CURLOPT_URL => "smec-group.com:9123/user/logout",
			CURLOPT_RETURNTRANSFER => true,
			CURLOPT_ENCODING => "",
			CURLOPT_MAXREDIRS => 10,
			CURLOPT_TIMEOUT => 30,
			CURLOPT_HTTP_VERSION => CURL_HTTP_VERSION_1_1,
			CURLOPT_CUSTOMREQUEST => "GET",
			CURLOPT_HTTPHEADER => array(
				"x-token: ".$this->session->userdata('token')
			),
		));

		$show=curl_exec($curl);
		
		$token=$this->session->userdata('token');
		$data['view']=$this->Log_model->view($token);
		
		$start_session=$data['view']->start_session;

		date_default_timezone_set("Asia/Bangkok");
		$end_session=date("Y-m-d H:i:s");
		$this->Log_model->update_logout($token,$start_session,$end_session);
		$this->session->sess_destroy();
		redirect();
	}
	function list_pasien(){
		$list = $this->Log_model->list_pasien();
		$data = array();
		$no = $_POST['start'];
		foreach ($list as $field) {
			$no++;
			$row = array();
			$row[] = $no;
			$row[] = $field->name;
			$row[] = $field->penyakit;

			$data[] = $row;
		}

		$output = array(
			"draw" => $_POST['draw'],
			"recordsTotal" => $this->Log_model->count_all(),
			"recordsFiltered" => $this->Log_model->count_filtered(),
			"data" => $data,
		);
		echo json_encode($output);
	}
}
