<?php 
    if(!empty($this->session->userdata('username')) || !empty($this->session->userdata('token')) || !empty($this->session->userdata('start_session'))){
        redirect('user/access');
    }
?>
<!doctype html>
<html lang="en">
  <head>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">

    <link rel="stylesheet" href="<?php echo base_url();?>assets/bootstrap/css/bootstrap.min.css">
    
    <!-- MY STYLE -->
    <link rel="stylesheet" href="<?php echo base_url();?>assets/style.css">

    <title>LOGIN</title>
  </head>
  <body>
    
    <div class="login-page">
      <div class="title">
        APPLICATION LOGIN
      </div>
      <?php 
            if(!empty($this->session->flashdata("not_found"))){
              ?>
                <div class="alert alert-danger"><?php echo $this->session->flashdata("not_found");?></div>
              <?php 
            }
          ?>
          <?php 
            if(!empty($this->session->flashdata("pass_wrong"))){
              ?>
                <div class="alert alert-danger"><?php echo $this->session->flashdata("pass_wrong");?></div>
              <?php 
            }
          ?>
      <div class="form">
          <?php 
            $attr=array(
              'class'=>'login-form'
            );
            echo form_open('',$attr);
          ?>
          <?php 
            if(!empty(validation_errors())){
              ?>
                <div class="text-danger"><?php echo validation_errors();?></div>
              <?php 
            }
          ?>
          <input type="text" placeholder="username" name="username" />
          <input type="password" placeholder="password" name="password" />
          <button type="submit">login</button>
          

          <?php echo form_close();?>
      </div>
    </div>


    <script src="<?php echo base_url();?>assets/bootstrap/js/jquery-3.3.1.slim.min.js"></script>
    <script src="<?php echo base_url();?>assets/bootstrap/js/bootstrap.min.js"></script>
  </body>
</html>