<?php 
if(empty($this->session->userdata('username')) || empty($this->session->userdata('token')) || empty($this->session->userdata('start_session'))){
  redirect();
}
?>
<!doctype html>
<html lang="en">
<head>
  <meta charset="utf-8">
  <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">

  <title>DATA PASIEN</title>

  <link rel="stylesheet" href="<?php echo base_url();?>assets/bootstrap/css/bootstrap.min.css">
  <link href="<?php echo base_url('assets/datatables/css/jquery.dataTables.min.css')?>" rel="stylesheet">
  <link rel="stylesheet" href="<?php echo base_url();?>assets/style.css">
  <script src="<?php echo base_url('assets/jquery-2.2.3.min.js')?>"></script>

</head>
<body>

  <div class="container">
    <div class="row">
      <div class="col-12">
        <div class="title">
          DATA PASIEN
        </div>
      </div>
    </div>

    <div class="row">
      <div class="col-12">
        <div class="btn-logout">
          <a class="btn btn-info" href="<?php echo site_url();?>user/logout">Logout</a>
        </div>
      </div>
    </div>
    <div class="row">
      <div class="col-12">
        <div class="table_pasien">
        <table id="tablepasien" class="display" cellspacing="0" width="100%">
          <thead>
            <tr>
              <th>No</th>
              <th>Nama</th>
              <th>Penyakit</th>
            </tr>
          </thead>
          <tbody>
          </tbody>
          <tfoot>
            <tr>
              <th>No</th>
              <th>Nama</th>
              <th>Penyakit</th>
            </tr>
          </tfoot>
        </table>
        </div>
      </div>
    </div>

    <div class="row">
      <div class="col-12">
        <div class="result_api">
        <?php 
          foreach($decode_data->data as $value){
            echo "Response data from API Access : <br>". $value."<br>";
          }
        ?>
        </div>
      </div>
    </div>
   <!--  <div class="row">
      <div class="col-12">
        <div class="result_api">
        <?php
          echo "Session Token : ". $this->session->userdata('token'); 
          echo "<br>";
          echo "Session Access : ". $this->session->userdata('access'); 
          echo "<br>";
          echo "Session Expries : ". $this->session->userdata('expires_in');
        ?>
        </div>
      </div>
    </div> -->
  </div>

  <script src="<?php echo base_url();?>assets/bootstrap/js/bootstrap.min.js"></script>
  <script src="<?php echo base_url('assets/datatables/js/jquery.dataTables.min.js')?>"></script>
  <script type="text/javascript">
    var table;
    $(document).ready(function() {
        
        table = $('#tablepasien').DataTable({ 
          "processing": true, 
          "serverSide": true, 
          "order": [], 

          "ajax": {
            "url": "<?php echo site_url('user/list_pasien')?>",
            "type": "POST"
          },
          "columnDefs": [
          { 
            "targets": [ 0 ], 
            "orderable": false, 
          },
          ],

        });
      });
    </script>
    
  </body>
  </html>